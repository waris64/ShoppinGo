import React from "react";
import Cart from "../../Components/Cart";
import { Dashboard } from "@mui/icons-material";
import SingleProduct from "../../Components/SingleProduct";
import RootLayout from "../../Components/NavBarPanel";

const LandingPage = () => {
  return (
    <div>
      {/* <RootLayout /> */}
      <Dashboard />
      {/* <Cart /> */}
      {/* <SingleProduct /> */}
    </div>
  );
};

export default LandingPage;
