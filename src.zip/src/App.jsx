import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Provider } from "react-redux";
import store from "./store/store";
import LandingPage from "./pages/LandingPage/Landing";
import Login from "./Components/Login";

function App() {
  return (
    <Provider store={store}>
      <Router>
        <Routes>
          <Route path="/landing-page" element={<LandingPage />} />
          <Route exact path="/" element={<Login />} />
        </Routes>
      </Router>
    </Provider>
  );
}

export default App;
